package Imobiliaria;

public interface Inter_CalculoValor {
	
	public interface CalculoValor{
		void calculoDesconto();
	}

}
