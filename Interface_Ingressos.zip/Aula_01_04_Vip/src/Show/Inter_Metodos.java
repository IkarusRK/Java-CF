package Show;

public interface Inter_Metodos {

	void valor(double quantia);

	String Status();

	double Preço();

    void ImprValor();
    
    void ImprStatus();
	
	
}
